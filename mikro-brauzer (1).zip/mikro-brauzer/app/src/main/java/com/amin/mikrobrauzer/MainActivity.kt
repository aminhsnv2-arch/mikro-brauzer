package com.amin.mikrobrauzer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private val fileBase = "https://appassets.androidplatform.net/"

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar

    private var currentFileName: String? = null
    private var pendingPerm: PermissionRequest? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    // ---- İcazələr (mikrofon / kamera) ----
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val r = pendingPerm ?: return@registerForActivityResult
            pendingPerm = null
            grantAllowed(r)
        }

    private fun androidPermFor(resource: String): String? = when (resource) {
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        else -> null
    }

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun grantAllowed(r: PermissionRequest) {
        val ok = r.resources.filter { res ->
            androidPermFor(res)?.let { hasPerm(it) } == true
        }
        if (ok.isEmpty()) r.deny() else r.grant(ok.toTypedArray())
    }

    // ---- HTML faylı seçmək ----
    private val pickHtml =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) openFile(uri)
        }

    // ---- Səhifənin öz <input type=file> üçün ----
    private val chooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
            )
            fileCallback = null
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun barButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { onClick() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#12101f"))
        }

        // ---- Üst panel ----
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1c1a30"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        urlBar = EditText(this).apply {
            setSingleLine(true)
            hint = "Ünvan və ya axtarış"
            setHintTextColor(Color.parseColor("#9a96b8"))
            setTextColor(Color.WHITE)
            textSize = 15f
            imeOptions = EditorInfo.IME_ACTION_GO
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setBackgroundColor(Color.parseColor("#2d2a4a"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                ) {
                    go(text.toString()); true
                } else false
            }
            setOnFocusChangeListener { _, has -> if (has) post { selectAll() } }
        }
        bar.addView(barButton("◀") { if (web.canGoBack()) web.goBack() })
        bar.addView(barButton("▶") { if (web.canGoForward()) web.goForward() })
        bar.addView(urlBar, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(barButton("⟳") { web.reload() })
        bar.addView(barButton("📂") { pickHtml.launch(arrayOf("*/*")) })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }

        // ---- WebView ----
        web = WebView(this)
        web.setBackgroundColor(Color.WHITE)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowContentAccess = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return false
                return s != "http" && s != "https" && s != "about" && s != "data" && s != "blob"
            }

            override fun onPageStarted(v: WebView, url: String, f: android.graphics.Bitmap?) {
                showUrl(url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                progress.progress = p
                progress.visibility = if (p in 1..99) View.VISIBLE else View.GONE
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    pendingPerm?.deny()
                    pendingPerm = null
                    val needed = request.resources.mapNotNull { androidPermFor(it) }.distinct()
                    if (needed.isEmpty()) { request.deny(); return@runOnUiThread }
                    val missing = needed.filter { !hasPerm(it) }
                    if (missing.isEmpty()) {
                        grantAllowed(request)
                    } else {
                        pendingPerm = request
                        permLauncher.launch(missing.toTypedArray())
                    }
                }
            }

            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    chooser.launch(p.createIntent()); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }

        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                        WindowInsetsCompat.Type.displayCutout() or
                        WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        if (!handleIntent(intent)) web.loadUrl("https://www.google.com")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?): Boolean {
        val d = i?.data
        if (i?.action != Intent.ACTION_VIEW || d == null) return false
        if (d.scheme == "http" || d.scheme == "https") web.loadUrl(d.toString()) else openFile(d)
        return true
    }

    // ---- Ünvan sətri ----
    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") ->
                "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
        currentFileName = null
        web.loadUrl(url)
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    private fun showUrl(url: String) {
        if (url.startsWith(fileBase) && currentFileName != null) {
            urlBar.setText("📄 $currentFileName")
        } else if (!urlBar.hasFocus()) {
            urlBar.setText(url)
        }
    }

    // ---- Yerli HTML faylı (https mənşəyi ilə -> mikrofon işləyir) ----
    private fun openFile(uri: Uri) {
        try {
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
            } ?: (uri.lastPathSegment ?: "fayl.html")
            val html = contentResolver.openInputStream(uri)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: throw IllegalStateException("Fayl oxunmadı")
            currentFileName = name
            web.loadDataWithBaseURL(fileBase, html, "text/html", "UTF-8", null)
        } catch (e: Exception) {
            Toast.makeText(this, "Açıla bilmədi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
